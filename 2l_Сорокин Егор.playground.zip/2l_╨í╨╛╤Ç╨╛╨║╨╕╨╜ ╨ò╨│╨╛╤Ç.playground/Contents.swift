import UIKit

// Задание 1. Написать функцию, которая определяет, четное число или нет.
func evenOrUneven ( _ number : Int) {
    if number % 2 == 0 {
    print ("\(number) - четное число")
    
    } else {
        print ("\(number) - нечетное число")
        
    }
}
let randomOne: () = evenOrUneven(341)

// Задание 2. Написать функцию, которая определяет, делится ли число без остатка на 3.
func divByThree ( _ number : Int) {
    if number % 3 == 0 {
        print ("\(number) делится без остатка на 3")
    } else {
        print ("\(number) не делится без остатка на 3")
        
    }
}
let randomTwo:() = divByThree(77)

// Задание 3. Создать возрастающий массив из 100 чисел.
var massif = [Int] ()
for i in 1...100 {
    massif.append(i)
}
print(massif)

// Задание 4. Удалить из этого массива все четные числа и все числа, которые не делятся на 3.
// Работаем с существующим массивом

for value in massif {
    if value % 2 == 0 || value % 3 != 0 {
        massif.remove (at: massif.firstIndex(of: value)!)
    }
}
print(massif)

// Создаем новый массив

var newMassif = [Int] ()
for i in 1...100 {
    if i % 2 != 0 && i % 3 == 0 {
        newMassif.append(i)
    }
}
print(newMassif)


// Задание 5. Написать функцию, которая добавляет в массив новое число Фибоначчи, и добавить при помощи нее 50 элементов. Числа Фибоначчи определяются соотношениями Fn=Fn-1 + Fn-2
func fibonacci (max: Int) -> Int {
    var firstNumber = 0
    var secondNumber = 1
    for _ in 0...max {
    let number = firstNumber
    firstNumber = secondNumber
    secondNumber += number
}
return firstNumber
}
func fibonacciArray (max: Int) -> [Int] {
    var array = [Int]()
    for i in 0..<max {
        array.append(fibonacci(max: i))
    }
    return array
}
print (fibonacciArray(max: 50))

// Задание 6. Заполнить массив элементов различными простыми числами. Натуральное число, большее единицы, называется простым, если оно делится только на себя и на единицу. Для нахождения всех простых чисел не больше заданного числа n (пусть будет 100), следуя методу Эратосфена, нужно выполнить следующие шаги:
//a. Выписать подряд все целые числа от двух до n (2, 3, 4, ..., n).
//b. Пусть переменная p изначально равна двум — первому простому числу.
//c. Зачеркнуть в списке числа от 2 + p до n, считая шагом p.
//d. Найти первое не зачёркнутое число в списке, большее, чем p, и присвоить значению переменной p это число.
//e. Повторять шаги c и d, пока возможно.

func isPrime (num: Int) -> Bool {
    for i in 2..<num {
        if num % i == 0 || num < 2 {
            return false
        }
    }
    return true
}
let prime = isPrime(num: )

var primeArray = [Int]()
for i in 2..<100 {
    if isPrime(num: i) {
        primeArray.append(i)
    }
}
print(primeArray)
